//package patterns_hw3;

public class Fast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
